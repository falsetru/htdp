import sys
try:
    raw_input
except NameError:
    raw_input = input

a = 'yaztqwme'
while 1:
    try:
        b = raw_input()
        if not b:
            break
    except EOFError:
        break
    if a < b:
        print('<')
    elif a > b:
        print('>')
    else:
        print('=')
    sys.stdout.flush()
